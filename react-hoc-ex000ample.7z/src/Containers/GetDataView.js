import React from 'react';

export default class GetDataView extends React.Component {
    constructor() {
        super();
        this.state = {};
    }

    render() {
        return (
            <div>
            </div>
        );
    }
}